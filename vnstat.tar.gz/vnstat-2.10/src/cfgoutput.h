#ifndef CFGOUTPUT_H
#define CFGOUTPUT_H

void printcfgfile(void);
void defaultcomment(const int isdefault);

#endif
