#ifndef CONFIG_TESTS_H
#define CONFIG_TESTS_H

void add_config_tests(Suite *s);

#endif
