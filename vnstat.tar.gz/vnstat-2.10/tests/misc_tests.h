#ifndef MISC_TESTS_H
#define MISC_TESTS_H

void add_misc_tests(Suite *s);

#endif
